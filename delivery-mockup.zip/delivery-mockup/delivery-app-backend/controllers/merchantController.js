/*
 * =================================================================
 * controllers/merchantController.js
 * =================================================================
 * แก้ไขการจัดการ error และการเรียกใช้ db.all ให้ถูกต้องและชัดเจนขึ้น
 */
const db = require('../config/db');

// ฟังก์ชันสำหรับดึงข้อมูลร้านค้าทั้งหมด
exports.getAllMerchants = (req, res) => {
  const sql = "SELECT merchant_id, merchant_name, description, cover_image_url FROM merchants WHERE is_open = 1";
  
  db.all(sql, [], (err, rows) => {
    if (err) {
      console.error("Database error in getAllMerchants:", err.message);
      // ตอบกลับเป็น JSON เสมอ เพื่อไม่ให้ Frontend เกิด SyntaxError
      return res.status(500).json({ message: 'เกิดข้อผิดพลาดในการดึงข้อมูลร้านค้า' });
    }
    res.json(rows);
  });
};

// --- [เพิ่ม] ฟังก์ชันสำหรับดึงข้อมูลร้านเดียวพร้อมเมนู ---
exports.getMerchantById = (req, res) => {
    const merchantId = req.params.id;
    
    // 1. ดึงข้อมูลร้านค้า
    const merchantSql = "SELECT * FROM merchants WHERE merchant_id = ?";
    db.get(merchantSql, [merchantId], (err, merchant) => {
        if (err) {
            console.error("DB error (getMerchantById - merchant):", err.message);
            return res.status(500).json({ message: 'เกิดข้อผิดพลาดที่เซิร์ฟเวอร์' });
        }
        if (!merchant) {
            return res.status(404).json({ message: 'ไม่พบร้านค้านี้' });
        }

        // 2. ดึงเมนูทั้งหมดของร้านค้านี้
        const menuSql = "SELECT * FROM menus WHERE merchant_id = ? AND is_available = 1";
        db.all(menuSql, [merchantId], (err, menus) => {
            if (err) {
                console.error("DB error (getMerchantById - menu):", err.message);
                return res.status(500).json({ message: 'เกิดข้อผิดพลาดที่เซิร์ฟเวอร์' });
            }

            // 3. รวมข้อมูลแล้วส่งกลับ
            const responseData = {
                ...merchant,
                menus: menus
            };
            res.json(responseData);
        });
    });
};

