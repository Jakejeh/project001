/*
 * =================================================================
 * server.js (ไฟล์หลักสำหรับรันเซิร์ฟเวอร์)
 * =================================================================
 * นี่คือหัวใจของเครื่องยนต์เราครับ ไฟล์นี้จะทำหน้าที่เปิดเซิร์ฟเวอร์
 * และรอรับคำสั่งจากหน้าเว็บ (Frontend)
 */
// เรียกใช้เครื่องมือที่จำเป็น
const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors'); // --- [เพิ่ม] บรรทัดที่ 1 ---
const { runDbMigration } = require('./databaseSetup'); // <-- [เพิ่ม] บรรทัดนี้

dotenv.config();
const app = express();

// --- [เพิ่ม] ส่วนนี้เพื่อสร้างตารางอัตโนมัติ ---
runDbMigration().catch(err => {
    console.error("Database migration failed:", err);
});
// ------------------------------------------

app.use(cors()); // --- [เพิ่ม] บรรทัดที่ 2 (สำคัญมาก ต้องอยู่ก่อน routes) ---
app.use(express.json());

app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/users', require('./routes/userRoutes')); // <-- [เพิ่ม] บรรทัดนี้
app.use('/api/merchants', require('./routes/merchantRoutes')); // <-- [เพิ่ม] บรรทัดนี้
app.use('/api/orders', require('./routes/orderRoutes')); // <-- [เพิ่ม] บรรทัดนี้

app.get('/api', (req, res) => {
  res.json({ message: 'ยินดีต้อนรับสู่ Delivery App Backend!' });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`เซิร์ฟเวอร์กำลังทำงานบนพอร์ต ${PORT}`);
});

