const db = require('../config/db');

exports.createOrder = (req, res) => {
    const { merchantId, addressId, paymentMethod, items, subtotal, deliveryFee, totalPrice } = req.body;
    const userId = 1; // <--- [แก้ไข] ใช้ user id 1 เป็นค่าตายตัว ไม่ต้อง Login

    if (!merchantId || !addressId || !paymentMethod || !items || items.length === 0) {
        return res.status(400).json({ message: 'ข้อมูลสำหรับสร้างออเดอร์ไม่ครบถ้วน' });
    }
    db.serialize(() => {
        db.run('BEGIN TRANSACTION');
        const orderSql = `INSERT INTO orders (user_id, merchant_id, address_id, order_status, subtotal, delivery_fee, total_price, payment_method) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
        const orderValues = [userId, merchantId, addressId, 'confirmed', subtotal, deliveryFee, totalPrice, paymentMethod];
        db.run(orderSql, orderValues, function(err) {
            if (err) {
                console.error("DB error (Insert Order):", err.message);
                db.run('ROLLBACK');
                return res.status(500).json({ message: `ไม่สามารถสร้างออเดอร์ได้: ${err.message}` });
            }
            const orderId = this.lastID;
            const itemSql = `INSERT INTO order_items (order_id, menu_id, quantity, price_at_order) VALUES (?, ?, ?, ?)`;
            const itemStmt = db.prepare(itemSql);
            const promises = items.map(item => new Promise((resolve, reject) => itemStmt.run(orderId, item.menu_id, item.quantity, item.price, (err) => err ? reject(err) : resolve())));
            Promise.all(promises)
                .then(() => {
                    itemStmt.finalize();
                    db.run('COMMIT', (err) => {
                        if (err) return res.status(500).json({ message: `Commit Error: ${err.message}` });
                        if (!res.headersSent) res.status(201).json({ message: 'สร้างออเดอร์สำเร็จ', orderId: orderId });
                    });
                })
                .catch(err => {
                    console.error("DB error (Insert Order Item):", err.message);
                    db.run('ROLLBACK');
                    if (!res.headersSent) res.status(500).json({ message: `เกิดข้อผิดพลาดในการบันทึกรายการอาหาร: ${err.message}` });
                });
        });
    });
};

exports.getOrderById = (req, res) => {
    const orderId = req.params.id;
    const orderSql = `SELECT o.*, m.merchant_name FROM orders o JOIN merchants m ON o.merchant_id = m.merchant_id WHERE o.order_id = ?`;
    db.get(orderSql, [orderId], (err, order) => {
        if (err) return res.status(500).json({ message: 'เกิดข้อผิดพลาดที่เซิร์ฟเวอร์' });
        if (!order) return res.status(404).json({ message: 'ไม่พบออเดอร์นี้' });
        // ไม่ต้องเช็ค user id แล้ว
        const itemsSql = "SELECT oi.quantity, oi.price_at_order, m.name FROM order_items oi JOIN menus m ON oi.menu_id = m.menu_id WHERE oi.order_id = ?";
        db.all(itemsSql, [orderId], (err, items) => {
            if (err) return res.status(500).json({ message: 'เกิดข้อผิดพลาดที่เซิร์ฟเวอร์' });
            res.json({ ...order, items });
        });
    });
};
