const jwt = require('jsonwebtoken');

module.exports = function(req, res, next) {
  // 1. ดึง Token จาก header ของ request
  const token = req.header('x-auth-token');

  // 2. ตรวจสอบว่ามี Token หรือไม่
  if (!token) {
    return res.status(401).json({ msg: 'ไม่มี Token, ไม่ได้รับอนุญาต' });
  }

  // 3. ตรวจสอบความถูกต้องของ Token
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    // ถ้า Token ถูกต้อง, ให้เก็บข้อมูล user ไว้ใน request เพื่อส่งต่อ
    req.user = decoded.user;
    next(); // อนุญาตให้ผ่านไปทำงานในขั้นต่อไป
  } catch (err) {
    res.status(401).json({ msg: 'Token ไม่ถูกต้อง' });
  }
};
