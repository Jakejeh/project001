/*
 * =================================================================
 * config/db.js (ไฟล์เดิมที่ต้องแก้ไขทั้งหมด)
 * =================================================================
 * เปลี่ยนจากการเชื่อมต่อ PostgreSQL มาเป็น SQLite
 * ตอนนี้ฐานข้อมูลของเราจะเป็นแค่ไฟล์ไฟล์เดียวชื่อ delivery_app.db
 */
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// ระบุตำแหน่งของไฟล์ฐานข้อมูล
const dbPath = path.resolve(__dirname, '../delivery_app.db');

// สร้างหรือเชื่อมต่อกับไฟล์ฐานข้อมูล
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Error opening database', err.message);
  } else {
    console.log('Connected to the SQLite database.');
    // เปิดใช้งาน Foreign Keys (สำคัญมากสำหรับ SQLite)
    db.exec('PRAGMA foreign_keys = ON;', (err) => {
        if (err) {
            console.error("Could not enable foreign keys", err);
        }
    });
  }
});

// ส่งออกฐานข้อมูลเพื่อให้ไฟล์อื่นใช้ได้
module.exports = db;