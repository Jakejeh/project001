/*
 * =================================================================
 * routes/authRoutes.js (ไฟล์ใหม่)
 * =================================================================
 * ไฟล์นี้จะทำหน้าที่เหมือน "สารบัญ" สำหรับ API ที่เกี่ยวกับการยืนยันตัวตนทั้งหมด
 * เช่น สมัครสมาชิก, เข้าสู่ระบบ
 */
const express = require('express');
const router = express.Router();
// ดึงฟังก์ชัน registerUser และ loginUser มาใช้งาน
const { registerUser, loginUser } = require('../controllers/authController');

// Route สำหรับสมัครสมาชิก (เหมือนเดิม)
router.post('/register', registerUser);

// Route สำหรับเข้าสู่ระบบ (ส่วนที่เพิ่มเข้ามาใหม่)
router.post('/login', loginUser);

module.exports = router;
