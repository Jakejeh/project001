const db = require('../config/db');

// ฟังก์ชันสำหรับดึงข้อมูลโปรไฟล์ของผู้ใช้ที่ Login อยู่
exports.getUserProfile = async (req, res) => {
  try {
    // req.user.id มาจาก Middleware ที่เราสร้างไว้
    const sql = `SELECT user_id, full_name, email, phone_number, profile_image_url FROM users WHERE user_id = ?`;
    db.get(sql, [req.user.id], (err, user) => {
        if (err) {
            console.error(err.message);
            return res.status(500).json({ message: 'เกิดข้อผิดพลาดที่เซิร์ฟเวอร์' });
        }
        if (!user) {
            return res.status(404).json({ message: 'ไม่พบผู้ใช้งาน' });
        }
        res.json(user);
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send('เกิดข้อผิดพลาดที่เซิร์ฟเวอร์');
  }
};

