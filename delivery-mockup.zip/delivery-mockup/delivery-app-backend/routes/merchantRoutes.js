const express = require('express');
const router = express.Router();
const { getAllMerchants, getMerchantById } = require('../controllers/merchantController');

// GET /api/merchants
// @desc    ดึงข้อมูลร้านค้าทั้งหมด
// @access  Public (ไม่ต้อง Login ก็ดูได้)
router.get('/', getAllMerchants);

router.get('/:id', getMerchantById);


module.exports = router;
