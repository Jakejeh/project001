/*
 * =================================================================
 * databaseSetup.js (ไฟล์ใหม่ที่ต้องสร้าง)
 * =================================================================
 * ไฟล์นี้คือ "ผู้สร้าง" ที่จะอ่านคำสั่ง SQL แล้วสร้างตารางทั้งหมดให้เรา
 */
const db = require('./config/db');
const fs = require('fs');
const path = require('path');

// ฟังก์ชันสำหรับรันสคริปต์ SQL
function runScript(script) {
  return new Promise((resolve, reject) => {
    db.exec(script, (err) => {
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    });
  });
}

// ฟังก์ชันหลักที่จะทำงาน
async function runDbMigration() {
  try {
    console.log('Running database migration...');
    const schemaPath = path.join(__dirname, 'db_schema.sql');
    const schemaSql = fs.readFileSync(schemaPath).toString();
    
    // แยกคำสั่ง SQL แต่ละ CREATE TABLE ออกจากกัน
    const statements = schemaSql.split(';').filter(s => s.trim().length > 0);

    // วนลูปสร้างทีละตาราง
    for (const statement of statements) {
      await runScript(statement + ';');
    }

    console.log('Database migration completed successfully.');
  } catch (error) {
    // ไม่ต้องทำอะไรถ้าตารางมีอยู่แล้ว
    if (error.message.includes("already exists")) {
        // console.log("Tables already exist. Skipping migration.");
    } else {
        console.error('Failed to run migration:', error.message);
    }
  }
}

module.exports = { runDbMigration };

