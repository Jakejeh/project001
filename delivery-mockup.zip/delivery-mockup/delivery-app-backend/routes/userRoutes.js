const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/authMiddleware');
const { getUserProfile } = require('../controllers/userController');

// GET /api/users/me
// @desc    ดึงข้อมูลโปรไฟล์ผู้ใช้ปัจจุบัน
// @access  Private (ต้องมี Token ถึงจะเข้าได้)
router.get('/me', authMiddleware, getUserProfile); // <--- เห็นมั้ยครับ เราเอา "ยาม" มาวางไว้ตรงกลาง

module.exports = router;

