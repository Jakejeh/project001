/*
 * =================================================================
 * controllers/authController.js (ไฟล์เดิมที่ต้องแก้ไขทั้งหมด)
 * =================================================================
 * เราจะเปลี่ยนโค้ดทั้งหมดในไฟล์นี้ให้ใช้ синтаксис ของ SQLite
 * และแก้ไขการเรียกใช้ฐานข้อมูลให้ถูกต้อง
 */
const db = require('../config/db'); // db object จาก sqlite3
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// ฟังก์ชันสำหรับจัดการการสมัครสมาชิก (ฉบับแก้ไขสำหรับ SQLite)
exports.registerUser = async (req, res) => {
  const { fullName, email, password, userType } = req.body;
  const phoneNumber = req.body.phoneNumber || null; // กำหนดค่า default เป็น null

  if (!fullName || !email || !password || !userType) {
    return res.status(400).json({ message: 'กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน' });
  }

  try {
    // 1. ตรวจสอบว่ามีอีเมลนี้ในระบบแล้วหรือยัง (ใช้ db.get สำหรับ SQLite)
    const sqlCheck = 'SELECT * FROM users WHERE email = ?';
    db.get(sqlCheck, [email], async (err, row) => {
      if (err) {
        console.error(err.message);
        return res.status(500).json({ message: 'เกิดข้อผิดพลาดในการตรวจสอบข้อมูล' });
      }
      if (row) {
        return res.status(400).json({ message: 'อีเมลนี้ถูกใช้งานแล้ว' });
      }

      // 2. เข้ารหัสรหัสผ่าน (เหมือนเดิม)
      const salt = await bcrypt.genSalt(10);
      const passwordHash = await bcrypt.hash(password, salt);

      // 3. บันทึกผู้ใช้ใหม่ลงในฐานข้อมูล (ใช้ db.run สำหรับ SQLite)
      const sqlInsert = `
        INSERT INTO users (full_name, email, password_hash, phone_number, user_type)
        VALUES (?, ?, ?, ?, ?)
      `;
      const values = [fullName, email, passwordHash, phoneNumber, userType];
      
      // ฟังก์ชัน .run ของ sqlite3 จะใช้ 'this' ใน callback เพื่อเข้าถึง id ที่เพิ่งสร้าง
      db.run(sqlInsert, values, function (err) {
        if (err) {
          console.error(err.message);
          return res.status(500).json({ message: 'เกิดข้อผิดพลาดในการบันทึกข้อมูล' });
        }
        
        const newUserId = this.lastID; // ดึง ID ของผู้ใช้ที่เพิ่งสร้าง

        // 4. สร้าง JSON Web Token (JWT)
        const payload = { user: { id: newUserId, type: userType } };
        jwt.sign(
          payload,
          process.env.JWT_SECRET,
          { expiresIn: '5h' },
          (err, token) => {
            if (err) throw err;
            // 5. ส่ง Token กลับไปให้ผู้ใช้
            res.status(201).json({ token });
          }
        );
      });
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).send('เกิดข้อผิดพลาดที่เซิร์ฟเวอร์');
  }
};


// ฟังก์ชันสำหรับจัดการการเข้าสู่ระบบ (ฉบับแก้ไขสำหรับ SQLite)
exports.loginUser = async (req, res) => {
    const { email, password } = req.body;

    try {
        const sql = 'SELECT * FROM users WHERE email = ?';
        db.get(sql, [email], async (err, user) => {
            if (err) {
                console.error(err.message);
                return res.status(500).json({ message: 'เกิดข้อผิดพลาดที่เซิร์ฟเวอร์' });
            }
            if (!user) {
                return res.status(400).json({ message: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง' });
            }

            const isMatch = await bcrypt.compare(password, user.password_hash);
            if (!isMatch) {
                return res.status(400).json({ message: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง' });
            }

            const payload = { user: { id: user.user_id, type: user.user_type } };
            jwt.sign(
                payload,
                process.env.JWT_SECRET,
                { expiresIn: '5h' },
                (err, token) => {
                    if (err) throw err;
                    res.json({ token });
                }
            );
        });
    } catch (error) {
        console.error(error.message);
        res.status(500).send('เกิดข้อผิดพลาดที่เซิร์ฟเวอร์');
    }
};
